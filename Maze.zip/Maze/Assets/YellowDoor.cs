﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class YellowDoor : MonoBehaviour {

	bool locked = true;
	bool opening = false;

	void Start () {

	}


	void Update () {

		if (opening) {
			Destroy (gameObject);
		}

	}

	public void OnYellowDoorClicked () {

		Debug.Log ("'Door.OnYellowDoorClicked()' was called");

		if (!locked) {
			opening = true;
		}
	}

	public void Unlock () {

		Debug.Log ("'Door.Unlock()' was called");

		locked = false;
	}
}
