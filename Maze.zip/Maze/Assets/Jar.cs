﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Jar : MonoBehaviour {


	void Start () {
		
	}
	

	void Update () {

		transform.Rotate (90 * Vector3.forward * Time.deltaTime);

	}


	public void OnJarClicked () {
		/// Called when the 'Key' game object is clicked
		/// - Unlocks the door (handled by the Door class)
		/// - Displays a poof effect (handled by the 'KeyPoof' prefab)
		/// - Plays an audio clip (handled by the 'KeyPoof' prefab)
		/// - Removes the key from the scene

		// Prints to the console when the method is called
		Debug.Log ("'Jar.OnJarClicked()' was called");

		Destroy (gameObject, 0.1f);
	}

}
