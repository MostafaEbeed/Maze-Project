﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GreenKey : MonoBehaviour {

	public GameObject KeyPoofPrefab;
	public GreenDoor greenDoor;

	void Start () {

	}


	void Update () {

		transform.Rotate (90 * Vector3.forward * Time.deltaTime);

	}


	public void OnGreenKeyClicked () {

		Debug.Log ("'Key.OnGreenKeyClicked()' was called");

		greenDoor.Unlock ();
		Instantiate (KeyPoofPrefab, transform);
		Destroy (gameObject, 0.1f);
	}
}
