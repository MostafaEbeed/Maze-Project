﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RedKey : MonoBehaviour {

	public GameObject KeyPoofPrefab;
	public RedDoor redDoor;

	void Start () {

	}


	void Update () {

		transform.Rotate (90 * Vector3.forward * Time.deltaTime);

	}


	public void OnRedKeyClicked () {

		Debug.Log ("'Key.OnRedKeyClicked()' was called");

		redDoor.Unlock ();
		Instantiate (KeyPoofPrefab, transform);
		Destroy (gameObject, 0.1f);
	}
}
