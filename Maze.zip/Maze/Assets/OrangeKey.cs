﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OrangeKey : MonoBehaviour {

	public GameObject KeyPoofPrefab;
	public OrangeDoor orangeDoor;

	void Start () {

	}


	void Update () {

		transform.Rotate (90 * Vector3.forward * Time.deltaTime);

	}


	public void OnOrangeKeyClicked () {

		Debug.Log ("'Key.OnOrangeKeyClicked()' was called");

		orangeDoor.Unlock ();
		Instantiate (KeyPoofPrefab, transform);
		Destroy (gameObject, 0.1f);
	}
}
