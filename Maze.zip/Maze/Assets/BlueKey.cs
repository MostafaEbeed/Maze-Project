﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlueKey : MonoBehaviour {


	public GameObject KeyPoofPrefab;
	public BlueDoor blueDoor;

	void Start () {
		
	}
	

	void Update () {

		transform.Rotate (90 * Vector3.forward * Time.deltaTime);

	}


	public void OnBlueKeyClicked () {
		
		Debug.Log ("'Key.OnBlueKeyClicked()' was called");

		blueDoor.Unlock ();
		Instantiate (KeyPoofPrefab, transform);
		Destroy (gameObject, 0.1f);
	}
}
