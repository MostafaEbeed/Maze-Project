﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class VioletDoor : MonoBehaviour {

	bool locked = true;
	bool opening = false;

	void Start () {

	}


	void Update () {

		if (opening) {
			Destroy (gameObject);
		}

	}

	public void OnVioletDoorClicked () {

		Debug.Log ("'Door.OnVioletDoorClicked()' was called");

		if (!locked) {
			opening = true;
		}
	}

	public void Unlock () {

		Debug.Log ("'Door.Unlock()' was called");

		locked = false;
	}
}
