﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class VioletKey : MonoBehaviour {

	public GameObject KeyPoofPrefab;
	public VioletDoor violetDoor;

	void Start () {

	}


	void Update () {

		transform.Rotate (90 * Vector3.forward * Time.deltaTime);

	}


	public void OnVioletKeyClicked () {

		Debug.Log ("'Key.OnVioletKeyClicked()' was called");

		violetDoor.Unlock ();
		Instantiate (KeyPoofPrefab, transform);
		Destroy (gameObject, 0.1f);
	}
}
