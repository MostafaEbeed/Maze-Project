﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class YellowKey : MonoBehaviour {

	public GameObject KeyPoofPrefab;
	public YellowDoor yellowDoor;

	void Start () {

	}


	void Update () {

		transform.Rotate (90 * Vector3.forward * Time.deltaTime);

	}


	public void OnYellowKeyClicked () {

		Debug.Log ("'Key.OnYellowKeyClicked()' was called");

		yellowDoor.Unlock ();
		Instantiate (KeyPoofPrefab, transform);
		Destroy (gameObject, 0.1f);
	}
}
